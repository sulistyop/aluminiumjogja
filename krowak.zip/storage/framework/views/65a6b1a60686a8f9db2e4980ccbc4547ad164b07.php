
<?php $__env->startSection('title','Krowak Art'); ?>
<?php $__env->startSection('content'); ?>


<div class="jumbotron jumbotron-fluid">
    <div class="container">
        <div class="row">
            <div class="col-12 col-sm-12 col-md-14 col-lg-6">
                <div class="wrapper-top mt-5">
                    <h2 class="font-weight-bold">SELAMAT DATANG DI KROWAK ART</h2>
                    <h5>Belanja Mebel Lebih Murah dan Mudah</h5>
                    <a name="" id="" class="btn btn-primary btn-top mt-3"
                        href="<?php echo e(route('produk.index')); ?>" role="button">Belanja Sekarang</a>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="container">
    <h2 class="mt-5 font-weight-bold">Kategori</h2>
    <div class="row">
        <?php $__currentLoopData = $kategori; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kategori): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-12 col-sm-12 col-md-3 col-lg-3 mt-4">
                <a
                    href="<?php echo e(route('produkkategori.index',['slug'=>$kategori->slug])); ?>">
                    <div class="card">
                        <div class="card-body">
                            <img src="<?php echo e(url('/storage/'.$kategori->image)); ?>"
                                class="card-img-top" alt="...">
                                
                        </div>
                    </div>
                </a>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    <h2 class="mt-5 font-weight-bold">Produk Terbaru</h2>
    <div class="content-produk-terbaru">
        <div class="row">
            <?php $__currentLoopData = $produk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $produk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-6 col-lg-3 col-md-6 col-sm-6 mt-5 card-product">
                    <a
                        href="<?php echo e(route('detailproduk.index',['slug'=>$produk->slug])); ?>">
                        <div class="card" style="">
                            <div class="card-body card-img p-2">
                
                                <img src="<?php echo e(url('storage/'.$produk->image)); ?>"
                                    class="card-img-top img-responsive" alt="...">
                                   
                            </div>
                            <div class="card-body">
                                <h5 class="card-title"><strong><?php echo e($produk->name); ?></strong></h5>

                                <p class="card-text">Rp.
                                    <?php echo e(number_format($produk->price,0,",",".")); ?>

                                </p>
                                <p class="card-text"><?php echo e($produk->category['name']); ?></p>
                                <p class="card-text"><?php echo e($produk->created_at->diffForHumans()); ?></p>
                            </div>
                        </div>
                    </a>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>







    <h2 class="mt-5 font-weight-bold">Layanan Kami</h2>
    <div class="content-layanan mt-5">
        <div class="row">
            <div class="col-12 col-md-4 col-lg-4">
                <div class="card text-center">
                    <div class="card-body">
                        <i class="fa fa-7x fa-shipping-fast p-3"></i>
                        <h5 class="card-title font-weight-bold mt-2">Bebas Ongkir</h5>

                    </div>
                </div>
            </div>

            <div class="col-12 col-md-4 col-lg-4">
                <div class="card text-center">
                    <div class="card-body">
                        <i class="fa fa-7x fa-check p-3"></i>
                        <h5 class="card-title font-weight-bold mt-2">Produk Original</h5>

                    </div>
                </div>
            </div>

            <div class="col-12 col-md-4 col-lg-4">
                <div class="card text-center">
                    <div class="card-body">
                        <i class="fa fa-7x fa-user-shield p-3"></i>
                        <h5 class="card-title font-weight-bold mt-2">24/7 Keluhan Layanan</h5>

                    </div>
                </div>
            </div>
        </div>
    </div>


</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Laravel-Ecommerce-Tokoku\resources\views/home/index.blade.php ENDPATH**/ ?>