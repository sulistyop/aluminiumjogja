
<?php $__env->startSection('title',$produk->name); ?>

<?php $__env->startSection('content'); ?>

<div class="container mt-5">

    <nav aria-label="breadcrumb white">
        <ol class="breadcrumb">
          <li class="breadcrumb-item"><a href="<?php echo e(route('home.index')); ?>">Home</a></li>
          <li class="breadcrumb-item"><a href="<?php echo e(route('produk.index')); ?>">Produk</a></li>
          <li class="breadcrumb-item active" aria-current="page">Produk Detail</li>
        </ol>
      </nav>

    <div class="row mt-5">
        <div class="col-12 col-sm-12 col-md-6 col-lg-6">
            <img src="<?php echo e(url('uploads/'.$produk->image)); ?>" style="width: 100%; height: 30vw; padding: 0"
                class="card-img-top" alt="...">
        </div>
        <div class="col-12 col-sm-12 col-md-6 col-lg-6">


            <h3><strong><?php echo e($produk->name); ?></strong></h3>
            <h5>Rp. <?php echo e(number_format($produk->price,0,",","." )); ?></h5>

            <table class="table mt-2">
                <tbody>
                    <tr>
                        <th scope="row">Status</th>
                        <td>:</td>
                        <td>
                            <?php if($produk->quantity == 0): ?>
                            <span class="badge badge-danger">Habis</span>
                            <?php else: ?>
                            <span class="badge badge-success">Tersedia</span>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">Kategori</th>
                        <td>:</td>
                        <td><?php echo e($produk->category['name']); ?></td>
                    </tr>
                    <tr>
                        <th scope="row">Stok</th>
                        <td>:</td>
                        <td><?php echo e($produk->quantity); ?></td>
                    </tr>
                    <tr>
                        <th scope="row">Jumlah</th>
                        <td>:</td>
                        <td>
                            <form action="<?php echo e(route('tambahkeranjang.index',['slug'=>$produk->slug])); ?>" method="post">
                                <?php echo csrf_field(); ?>
                                <input type="text" class="form-control text-center" name="total" value="1">
                        </td>
                    </tr>
                </tbody>
            </table>
            <?php if(!auth()->check() || ! auth()->user()->hasRole('admin')): ?>
                <button type="submit" class="btn btn-primary w-100 mt-2"> <i class="fa fa-shopping-cart mr-2"></i> Tambah
                Keranjang</button>
            <?php endif; ?>
            </form>

            <nav class="mt-5">
                <div class="nav nav-tabs" id="nav-tab" role="tablist">
                  <a class="nav-item nav-link active" id="nav-home-tab" data-toggle="tab" href="#nav-home" role="tab" aria-controls="nav-home" aria-selected="true">Deskripsi</a>
                </div>
              </nav>
              <div class="tab-content" id="nav-tabContent">
                <div class="tab-pane fade show active" id="nav-home" role="tabpanel" aria-labelledby="nav-home-tab">
                    <div class="container">
                        <p class="pt-2">
                            <?php echo e($produk->desc); ?>

                        </p>
                    </div>
                </div>
              </div>
        </div>
    </div>

</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\sulis\Downloads\Compressed\krowak\krowak\resources\views/produk/detail.blade.php ENDPATH**/ ?>