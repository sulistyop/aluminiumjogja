
<?php $__env->startSection('title','Profil'); ?>

<?php $__env->startSection('content'); ?>

<div class="container mt-4">
    <nav aria-label="breadcrumb white">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="<?php echo e(route('home.index')); ?>">Beranda</a></li>
            <li class="breadcrumb-item active" aria-current="page">Profil</li>
        </ol>
    </nav>
    <div class="col-8 mx-auto">
        <h3 class="text-center mb-5"><strong>Profil</strong></h3>

        <form action="<?php echo e(route('updateprofile.index')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <label>Nama</label>
                <input type="text" name="name" class="form-control" value="<?php echo e($user->name); ?>">
            </div>
            <div class="form-group">
                <label>Email</label>
                <input type="email" name="email" value="<?php echo e($user->email); ?>" class="form-control">
            </div>
            <div class="form-group">
                <label>No Hp</label>
                <input type="text" name="phone" value="<?php echo e($user->phone); ?>" class="form-control" placeholder="No Hp" maxlength="12">
            </div>
            <div class="form-group">
                <label for="">Alamat Lengkap/Tujuan Pengiriman</label>
                <textarea class="form-control" name="address" name="" id="" rows="3" placeholder="Alamat Lengkap"><?php echo e($user->address); ?></textarea>
            </div>
            <div class="form-group">
                <label>Kota/Kabupaten</label>
                <input type="text" name="city" value="<?php echo e($user->city); ?>" class="form-control" placeholder="Kota/Kabupaten">
            </div>
            <div class="form-group">
                <label>Kode Pos</label>
                <input type="text" name="zipcode" value="<?php echo e($user->zipcode); ?>" class="form-control" placeholder="Kode Pos">
            </div>
            <button type="submit" class="btn btn-primary w-100 mt-3 mb-3">Simpan</button>
        </form>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\sulis\Downloads\Compressed\krowak\krowak\resources\views/profile/index.blade.php ENDPATH**/ ?>