
<?php $__env->startSection('title','Detail Pemesanan'); ?>

<?php $__env->startSection('content'); ?>

<div class="container">
    <div class="row">
        <div class="col-12 col-sm-12 col-md-12 col-lg-12">

            <div class="card">
                <div class="card-body">
                    <h2 class="mb-5 float-right">Tokoku.</h2>
                    <h6>Nama : <?php echo e($order->user['name']); ?></h6>
                    <h6>Alamat : <?php echo e($order->user['address']); ?></h6>
                    <h6>Kota : <?php echo e($order->user['city']); ?></h6>
                    <h6>Kodepos : <?php echo e($order->user['zipcode']); ?></h6>
                    <h6>Status :
                        <?php if($order->status == 'checkout'): ?>
                            Belum Dibayar
                        <?php else: ?>
                            Sudah Dibayar
                        <?php endif; ?>
                    </h6>
                    <h6>Total : Rp. <?php echo e(number_format($order->total_price + $order->code,0,",",".")); ?></h6>
                    <h6>Tanggal/Waktu : <?php echo e($order->order_date->format('d/m/Y h:i:s')); ?></h6>
                </div>

                <div class="card-body">
                    <table class="table">
                        <thead>
                          <tr>
                            <th scope="col">No</th>
                            <th scope="col">Gambar</th>
                            <th scope="col">Nama Produk</th>
                            <th scope="col">Jumlah</th>
                            <th scope="col">Harga</th>
                            <th scope="col">Total Harga</th>
                          </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $order_detail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order_detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <th scope="row"><?php echo e($loop->iteration); ?></th>
                                <td><img style="width: 70px" src="<?php echo e(url('/storage/'.$order_detail->product['image'])); ?>" alt=""></td>
                                <td><?php echo e($order_detail->product['name']); ?></td>
                                <td><?php echo e($order_detail->total); ?> unit</td>
                                <td>Rp. <?php echo e(number_format($order_detail->product['price'],0,",",".")); ?></td>
                                <td>Rp. <?php echo e(number_format($order_detail->total_price,0,",",".")); ?></td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td colspan="5" class="text-right"><Strong>Total</Strong></td>
                                <td><strong>Rp. <?php echo e(number_format($order->total_price,0,",",".")); ?></strong></td>
                            </tr>
                            <tr>
                                <td colspan="5" class="text-right"><Strong>Kode Unik</Strong></td>
                                <td><strong>Rp. <?php echo e(number_format($order->code,0,",",".")); ?></strong></td>
                            </tr>
                            <tr>
                                <td colspan="5" class="text-right"><Strong>Total yang harus ditransfer</Strong></td>
                                <td><strong>Rp. <?php echo e(number_format($order->total_price + $order->code,0,",",".")); ?></strong></td>
                            </tr>
                            <tr>
                                <td colspan="5" class="text-right"></td>
                                <td><a href="<?php echo e(route('pemesanan.admin')); ?>" class="btn btn-primary">Kembali</a></td>
                            </tr>
                        </tbody>
                      </table>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Project\Laravel-Ecommerce-Tokoku\resources\views/admin/pemesananDetail.blade.php ENDPATH**/ ?>