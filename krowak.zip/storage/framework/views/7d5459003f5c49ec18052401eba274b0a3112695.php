

<?php $__env->startSection('title','Detail Pengguna'); ?>

<?php $__env->startSection('content'); ?>

<div class="card h-100">
    <div class="card-header">
        Detail Pengguna
    </div>
    <div class="card-body">

                <table class="table mt-2">
                    <tbody>
                        <tr>
                            <th scope="row">Nama</th>
                            <td>:</td>
                            <td><?php echo e($user->name); ?></td>
                        </tr>
                        <tr>
                            <th scope="row">Email</th>
                            <td>:</td>
                            <td><?php echo e($user->email); ?></td>
                        </tr>
                        <tr>
                            <th scope="row">Alamat</th>
                            <td>:</td>
                            <td><?php echo e($user->address); ?></td>
                        </tr>
                        <tr>
                            <th scope="row">Kota</th>
                            <td>:</td>
                            <td><?php echo e($user->city); ?></td>
                        </tr>
                        <tr>
                            <th scope="row">Kode Pos</th>
                            <td>:</td>
                            <td><?php echo e($user->zipcode); ?></td>
                        </tr>
                    </tbody>
                </table>


                <a name="" id="" class="btn btn-warning" href="" role="button"><i class="fa fa-pen"></i></a>
                    
            </div>


    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Laravel-Ecommerce-Tokoku\resources\views/admin/detailPengguna.blade.php ENDPATH**/ ?>