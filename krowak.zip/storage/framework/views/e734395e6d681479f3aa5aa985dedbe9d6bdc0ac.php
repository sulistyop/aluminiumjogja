

<?php $__env->startSection('title','Dashboard Admin'); ?>

<?php $__env->startSection('content'); ?>

<div class="row">
    <div class="col-4 col-sm-4 col-md-4 col-lg-4">
        <div class="card" style="height: 10rem;">
            <div class="card-header">
                User
            </div>
            <div class="card-body">
                <blockquote class="blockquote mb-0">
                    <h4><?php echo e($usercount); ?></h4>
                </blockquote>
            </div>
        </div>
    </div>
    <div class="col-4 col-sm-4 col-md-4 col-lg-4">
        <div class="card" style="height: 10rem;">
            <div class="card-header">
                Produk
            </div>
            <div class="card-body">
                <blockquote class="blockquote mb-0">
                    <h4><?php echo e($produkcount); ?></h4>
                </blockquote>
            </div>
        </div>
    </div>
    <div class="col-4 col-sm-4 col-md-4 col-lg-4">
        <div class="card" style="height: 10rem;">
            <div class="card-header">
                Pendapatan
            </div>
            <div class="card-body">
                <blockquote class="blockquote mb-0">
                    <h4>Rp. <?php echo e(number_format($order_total,0,",",".")); ?></h4>
                </blockquote>
            </div>
        </div>
    </div>
</div>

<div class="wrapper-order mt-5">
    <div class="card">
        <div class="card-header">
            Pemesanan Terbaru
        </div>
        <div class="card-body">
            <table class="table">
                <thead class="thead-light">
                    <tr>
                        <th scope="col">No</th>
                        <th scope="col">Tanggal/Waktu</th>
                        <th scope="col">Nama Pemesan</th>
                        <th scope="col">Status</th>
                        <th scope="col">Total</th>
                        <th scope="col">Detail</th>
                        <th scope="col">Bayar</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $order; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <th scope="row"><?php echo e($loop->iteration); ?></th>
                        <td><?php echo e($order->order_date); ?></td>
                        <td><?php echo e($order->user['name']); ?></td>
                        <td>
                            <?php if($order->status == 'checkout'): ?>
                                Belum Dibayar
                            <?php else: ?>
                                Sudah Dibayar
                            <?php endif; ?>
                        </td>
                        <td>Rp. <?php echo e(number_format($order->total_price += $order->code,0,",",".")); ?></td>
                        <td>
                            <a name="" id="" class="btn btn-primary" href="<?php echo e(route('pemesananDetail.admin',['slug'=>$order->slug])); ?>" role="button">
                                <i class="fa fa-search"></i>
                            </a>
                        </td>
                        <td>
                            <form action="<?php echo e(route('bayar', $order->id)); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('POST'); ?>
                                <button type="submit" class="btn btn-primary">Bayar</button>
                            </form>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
    <div class="card mt-2">
        <div class="card-header">
            Pemesanan Lunas
        </div>
        <div class="card-body">
            <table class="table">
                <thead class="thead-light">
                    <tr>
                        <th scope="col">No</th>
                        <th scope="col">Tanggal/Waktu</th>
                        <th scope="col">Nama Pemesan</th>
                        <th scope="col">Status</th>
                        <th scope="col">Total</th>
                        <th scope="col">Detail</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $orderLunas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <th scope="row"><?php echo e($loop->iteration); ?></th>
                        <td><?php echo e($order->order_date); ?></td>
                        <td><?php echo e($order->user['name']); ?></td>
                        <td>
                            <?php if($order->status == 'checkout'): ?>
                                Belum Dibayar
                            <?php else: ?>
                                Sudah Dibayar
                            <?php endif; ?>
                        </td>
                        <td>Rp. <?php echo e(number_format($order->total_price += $order->code,0,",",".")); ?></td>
                        <td>
                            <a name="" id="" class="btn btn-primary" href="<?php echo e(route('pemesananDetail.admin',['slug'=>$order->slug])); ?>" role="button">
                                <i class="fa fa-search"></i>
                            </a>
                        </td>
                       
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\krowak\resources\views/admin/index.blade.php ENDPATH**/ ?>