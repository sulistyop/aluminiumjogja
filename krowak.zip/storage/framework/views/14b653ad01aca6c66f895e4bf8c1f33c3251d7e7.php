

<?php $__env->startSection('title','Pengguna'); ?>

<?php $__env->startSection('content'); ?>

<div class="card h-100">
    <div class="card-header">
        Pengguna
    </div>
    <div class="card-body">
        <div class="row">
            <div class="col-12 col-sm-12 col-md-8 col-lg-8">
                <a name="" id="" class="btn btn-primary mb-3" href="<?php echo e(route('tampiltambahpengguna.admin')); ?>" role="button">+ Tambah
                    Pengguna</a>
            </div>
            <div class="col-12 col-sm-12 col-md-4 col-lg-4">
                <form action="<?php echo e(route('cariuser.admin')); ?>" method="get">
                    <div class="input-group">
                        <input type="text" name="cari" class="form-control" placeholder="Cari Pengguna..." value<?php echo e(old('cari')); ?>>
                        <button type="submit" class="btn btn-primary"><i class="fa fa-search"></i></button>
                    </div>
                </form>
            </div>
        </div>
        <table class="table">
            <thead class="thead-light">
                <tr>
                    <th scope="col">No</th>
                    <th scope="col">Nama</th>
                    <th scope="col">Email</th>
                    <th scope="col">Alamat</th>
                    <th scope="col">Detail</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $pengguna; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $no => $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <th scope="row"><?php echo e($pengguna->firstItem() + $no); ?></th>
                    <td><?php echo e($data->name); ?></td>
                    <td><?php echo e($data->email); ?></td>
                    <td><?php echo e($data->address); ?></td>
                    <td>
                        <a class="btn btn-sm btn-primary" href="<?php echo e(route('detailuser.admin',['slug'=>$data->slug])); ?>" role="button"><i class="fa fa-search"></i></a>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
        <?php echo e($pengguna->onEachSide(2)->links()); ?>

    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Laravel-Ecommerce-Tokoku\resources\views/admin/pengguna.blade.php ENDPATH**/ ?>