

<?php $__env->startSection('title','Tambah Produk'); ?>

<?php $__env->startSection('content'); ?>

<div class="card">
    <div class="card-header">
        Tambah Produk
    </div>
    <div class="card-body">
        <form action="<?php echo e(route('tambahproduk.admin')); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="row">
                <div class="col">
                    <div class="form-group">
                        <label for="exampleInputEmail1">Nama</label>
                        <input type="text" name="name" class="form-control" id="" value="<?php echo e(old('name')); ?>" aria-describedby="" placeholder="Nama produk">
                      </div>
                </div>
                <div class="col">
                    <div class="form-group">
                        <label for="exampleFormControlSelect1">Kategori</label>
                        <select class="form-control" name="category_id" id="">
                          <option selected>Pilih Produk</option>
                            <?php $__currentLoopData = $kategori; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kategori): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($kategori->id); ?>"><?php echo e($kategori->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                      </div>
                </div>
            </div>
            <div class="row">
                <div class="col">
                    <div class="form-group">
                        <label for="exampleInputEmail1">Harga</label>
                        <input type="text" name="price" class="form-control" value="<?php echo e(old('price')); ?>" id="rupiah2" aria-describedby="" placeholder="Rp.">
                      </div>
                </div>
                <div class="col">
                    <div class="form-group">
                        <label for="exampleInputEmail1">Stok</label>
                        <input type="string" name="quantity" class="form-control" value="<?php echo e(old('quantity')); ?>" id="" aria-describedby="" placeholder="Jumlah Produk">
                      </div>
                </div>
            </div>
              <div class="form-group">
                <label for="exampleInputEmail1">Deskripsi</label>
                <textarea type="" name="desc" class="form-control" rows="5" aria-describedby="" placeholder="Deskripsi Produk"><?php echo e(old('desc')); ?></textarea>
              </div>
              <label for="exampleInputEmail1">Gambar Produk</label>
              <div class="custom-file">
                <input type="file" class="custom-file-input" name="image" id="customFile">
                <label class="custom-file-label" for="customFile">Pilih Foto</label>
              </div>
            <button type="submit" class="btn btn-primary w-100 mt-3">Tambah</button>
          </form>

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\krowak\resources\views/admin/tambahProduk.blade.php ENDPATH**/ ?>