
<?php $__env->startSection('title','Checkout'); ?>

<?php $__env->startSection('content'); ?>

<div class="container mt-4">
    <nav aria-label="breadcrumb white">
        <ol class="breadcrumb">
          <li class="breadcrumb-item"><a href="<?php echo e(route('home.index')); ?>">Beranda</a></li>
          <li class="breadcrumb-item"><a href="<?php echo e(route('keranjang.index')); ?>">Keranjang</a></li>
          <li class="breadcrumb-item active" aria-current="page">Checkout</li>
        </ol>
      </nav>

            
            <table class="table">
                <thead>
                    <tr>
                        <th scope="col">No</th>
                        <th scope="col">Gambar</th>
                        <th scope="col">Nama Produk</th>
                        <th scope="col">Jumlah</th>
                        <th scope="col">Harga</th>
                        <th scope="col">Total Harga</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $order_detail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order_detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <th scope="row"><?php echo e($loop->iteration); ?></th>
                        <td>
                            <a href="<?php echo e(route('detailproduk.index',['slug'=>$order_detail->product['slug']])); ?>">
                                <img style="width: 10rem" src="<?php echo e(url('/storage/'.$order_detail->product['image'])); ?>"
                                alt="">
                            </a>
                        </td>
                        <td><?php echo e($order_detail->product['name']); ?></td>
                        <td><?php echo e($order_detail->total); ?> unit</td>
                        <td>Rp. <?php echo e(number_format($order_detail->product['price'],0,",",".")); ?></td>
                        <td>
                            <strong>
                                Rp. <?php echo e(number_format($order_detail->total_price,0,",",".")); ?>

                            </strong>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td colspan="5" class="text-right"><Strong>Total</Strong></td>
                        <td><strong>Rp. <?php echo e(number_format($order->total_price,0,",",".")); ?></strong></td>
                        <td></td>
                    </tr>
                    <tr>
                        <td colspan="5" class="text-right"><Strong>Kode Unik</Strong></td>
                        <td><strong>Rp. <?php echo e(number_format($order->code)); ?></strong></td>
                        <td></td>
                    </tr>
                    <tr>
                        <td colspan="5" class="text-right"><Strong>Total yang harus dibayar</Strong></td>
                        <td><strong>Rp. <?php echo e(number_format($order->total_price + $order->code,0,",",".")); ?></strong></td>
                        <td></td>
                    </tr>
                </tbody>
            </table>

            <h2 class="mt-3 mb-5 font-weight-bold">Identitas Pengiriman</h2>

            <form action="<?php echo e(route('checkout.index')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <div class="row">
                    <div class="col">
                        <div class="form-group">
                            <label>Nama</label>
                            <input type="text" name="name" class="form-control" value="<?php echo e($user->name); ?>">
                        </div>
                    </div>
                    <div class="col">
                        <div class="form-group">
                            <label>Email</label>
                            <input type="email" name="email" value="<?php echo e($user->email); ?>" class="form-control">
                        </div>
                    </div>
                </div>


                <div class="form-group">
                    <label>No Hp</label>
                    <input type="text" name="phone" value="<?php echo e($user->phone); ?>" class="form-control" placeholder="No Hp" maxlength="12">
                </div>
                <div class="form-group">
                    <label for="">Alamat Lengkap/Tujuan Pengiriman</label>
                    <textarea class="form-control" name="address" name="" id="" rows="3" placeholder="Alamat Lengkap"><?php echo e($user->address); ?></textarea>
                </div>
                <div class="row">
                    <div class="col">
                        <div class="form-group">
                            <label>Kota/Kabupaten</label>
                            <input type="text" name="city" value="<?php echo e($user->city); ?>" class="form-control" placeholder="Kota/Kabupaten">
                        </div>

                    </div>
                    <div class="col">
                        <div class="form-group">
                            <label>Kode Pos</label>
                            <input type="text" name="zipcode" value="<?php echo e($user->zipcode); ?>" class="form-control" placeholder="Kode Pos">
                        </div>

                    </div>
                </div>
                <button type="submit" class="btn btn-success w-100 mt-3 mb-3">Checkout</button>
            </form>

        
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\krowak\resources\views/checkout/index.blade.php ENDPATH**/ ?>