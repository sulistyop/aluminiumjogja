

<?php $__env->startSection('title','Kategori Produk'); ?>

<?php $__env->startSection('content'); ?>

<div class="card">
    <div class="card-header">
        Kategori Produk
    </div>
    <div class="card-body">
        <form action="<?php echo e(route('tambahkategori.admin')); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="row">
                <div class="col">
                    <div class="form-group">
                        <label for="exampleInputEmail1">Tambah Kategori</label>
                        <input type="text" name="name" class="form-control" id="" aria-describedby=""  placeholder="Kategori">
                    </div>

                </div>
                <div class="col">
                    <label for="exampleInputEmail1">Gambar Kategori</label>
                    <div class="custom-file">
                        <input type="file" class="custom-file-input" name="image" id="customFile">
                        <label class="custom-file-label" for="customFile">Pilih Gambar</label>
                      </div>

                </div>
            </div>
            <button type="submit" class="btn btn-primary w-100 mt-3">Simpan</button>
        </form>

        <table class="table mt-3">
            <thead class="thead-light">
                <tr>
                    <th scope="col">No</th>
                    <th scope="col">Gambar</th>
                    <th scope="col">Nama</th>
                    <th scope="col">Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $kategori; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $no => $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <th scope="row"><?php echo e($kategori->firstItem() + $no); ?></th>
                    <td><img style="width: 70px" src="<?php echo e(url('/storage/'.$data->image)); ?>" alt=""></td>
                    <td><?php echo e($data->name); ?></td>
                    <td>
                        <a name="" id="" class="btn btn-sm btn-warning" href="<?php echo e(route('tampilubahkategori.admin',['slug'=>$data->slug])); ?>" role="button"><i class="fa fa-pen"></i></a>
                        <form class="d-inline" action="<?php echo e(route('hapuskategori.admin',['slug'=>$data->slug])); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('delete'); ?>
                            <button  type="submit" class="btn btn-sm btn-danger" role="button"><i class="fa fa-trash"></i></button>
                        </form>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
        <?php echo e($kategori->onEachSide(2)->links()); ?>

    </div>
</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\sulis\Downloads\Compressed\krowak\krowak\resources\views/admin/category.blade.php ENDPATH**/ ?>