
<?php $__env->startSection('title','Produk'); ?>

<?php $__env->startSection('content'); ?>

<div class="container mt-5">
    <div class="wrapper-produk">
        <div class="row">
            <div class="col-12 col-md-3 col-lg-3">
                <h3 class="font-weight-bold">Kategori</h3>
                <div class="card mt-5">
                    <?php
                        $all = App\Product::all()->count();
                    ?>
                    <ul class="list-group list-group-flush">
                        <li class="list-group-item">
                            <a class="<?php echo e(set_active('produk.index')); ?>" href="<?php echo e(route('produk.index')); ?>">Semua</a>
                            <span class="badge badge-dark float-right"><?php echo e($all); ?></span>
                        </li>
                        <?php $__currentLoopData = $kategori; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li class="list-group-item">
                                <a class="<?php echo e(set_active('produkkategori.index*')); ?>"
                                    href="<?php echo e(route('produkkategori.index',['slug'=>$kat->slug])); ?>"><?php echo e($kat->name); ?></a>
                                <span class="badge badge-dark float-right"><?php echo e($kat->product_count); ?></span>
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            </div>
            <div class="col-12 col-md-9 col-lg-9">
                <div class="row">
                    <div class="col-12 col-sm-12 col-md-8 col-lg-8">
                        <h3 class="font-weight-bold">Produk</h3>

                    </div>
                    <div class="col-12 col-sm-12 col-md-4 col-lg-4">
                        <form class="mr-auto" action="<?php echo e(route('cariproduk.index')); ?>" method="get">
                            <div class="input-group">
                                <input type="text" name="cari" class="form-control" placeholder="Cari Produk..." id="">
                            </div>
                        </form>
                    </div>
                </div>
                <div class="row mt-5">
                    <?php $__currentLoopData = $produk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $no => $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-12 col-sm-6 col-lg-4 col-md-4 mb-4 card-product">
                            <a
                                href="<?php echo e(route('detailproduk.index',['slug'=>$data->slug])); ?>">
                                <div class="card">
                                    <img src="<?php echo e(url('/storage/'.$data->image)); ?>"
                                        class="card-img-top" alt="...">
                                    <div class="card-body">

                                            <h5 class="card-title"><strong><?php echo e($data->name); ?></strong></h5>

                                        <p class="card-text">Rp.
                                            <?php echo e(number_format($data->price,0,",",".")); ?>

                                        </p>
                                        <p class="card-text"><?php echo e($data->category['name']); ?></p>
                                        <p class="card-text"><?php echo e($data->created_at->diffForHumans()); ?></p>
                                    </div>
                                </div>
                            </a>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <div class="mt-3">
                    <?php echo e($produk->links()); ?>

                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Project\Laravel-Ecommerce-Tokoku\resources\views/produk/index.blade.php ENDPATH**/ ?>