
<?php $__env->startSection('title','Detail Riwayat Belanja'); ?>

<?php $__env->startSection('content'); ?>

<div class="container mt-4">
    <nav aria-label="breadcrumb white">
        <ol class="breadcrumb">
          <li class="breadcrumb-item"><a href="<?php echo e(route('home.index')); ?>">Home</a></li>
          <li class="breadcrumb-item"><a href="<?php echo e(route('history.index')); ?>">Riwayat Belanja</a></li>
          <li class="breadcrumb-item active" aria-current="page">Detail</li>
        </ol>
      </nav>
      <div class="d-block overflow-auto">
         <div class="float-right">
            <a href="<?php echo e(route('cetakhistorydetail.index',['slug'=>$order->slug])); ?>" class="btn btn-primary"><i class="fa fa-print"></i> Cetak</a>
         </div>
      </div>
            <div class="card mt-3">
                <div class="card-body">
                    <h4>Pemesanan Sukses</h4>
                    <h6>Pemesanan anda sukses selanjutnya untuk melakukan pembayaran melalui transfer
                        <br>
                        di rekening <strong>Bank BRI Nomer Rekening : 31212-7533545-200</strong>
                        dengan nominal <strong>Rp. <?php echo e(number_format($order->total_price + $order->code,0,",",".")); ?></strong>

                        <br>
                        kirim bukti tranfer ke nomor <strong>WA : 087712334515</strong>
                    </h6>
                </div>
            </div>

            <div class="card mt-3">
                <div class="card-body">
                    <table class="table">
                        <thead>
                          <tr>
                            <th scope="col">No</th>
                            <th scope="col">Gambar</th>
                            <th scope="col">Nama Produk</th>
                            <th scope="col">Jumlah</th>
                            <th scope="col">Harga</th>
                            <th scope="col">Total Harga</th>
                          </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $order_detail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order_detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <th scope="row"><?php echo e($loop->iteration); ?></th>
                                <td><img style="width: 70px" src="<?php echo e(url('/storage/'.$order_detail->product['image'])); ?>" alt=""></td>
                                <td><?php echo e($order_detail->product['name']); ?></td>
                                <td><?php echo e($order_detail->total); ?> unit</td>
                                <td>Rp. <?php echo e(number_format($order_detail->product['price'],0,",",".")); ?></td>
                                <td><strong>Rp. <?php echo e(number_format($order_detail->total_price,0,",",".")); ?></strong></td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td colspan="5" class="text-right"><Strong>Total</Strong></td>
                                <td><strong>Rp. <?php echo e(number_format($order->total_price,0,",",".")); ?></strong></td>
                            </tr>
                            <tr>
                                <td colspan="5" class="text-right"><Strong>Kode Unik</Strong></td>
                                <td><strong>Rp. <?php echo e(number_format($order->code,0,",",".")); ?></strong></td>
                            </tr>
                            <tr>
                                <td colspan="5" class="text-right"><Strong>Total yang harus ditransfer</Strong></td>
                                <td><strong>Rp. <?php echo e(number_format($order->total_price + $order->code,0,",",".")); ?></strong></td>
                            </tr>
                        </tbody>
                      </table>
                </div>
            </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\krowak\resources\views/checkout/detailHistory.blade.php ENDPATH**/ ?>