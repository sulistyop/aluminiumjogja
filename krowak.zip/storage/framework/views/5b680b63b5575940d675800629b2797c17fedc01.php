

<?php $__env->startSection('title','Ubah Produk'); ?>

<?php $__env->startSection('content'); ?>

<div class="card">
    <div class="card-header">
        Ubah Produk
    </div>
    <div class="card-body">
        <div class="row">
            <div class="col-12 col-sm-12 col-md-4 col-lg-4">
                <form action="<?php echo e(route('updateproduk.admin',['slug'=>$produk->slug])); ?>" method="POST"
                    enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="form-group">
                        <img src="<?php echo e(url('/storage/'.$produk->image)); ?>" style="width: 100%" alt="">
                    </div>
                    <div class="custom-file">
                        <input type="file" class="custom-file-input" name="image" id="customFile">
                        <label class="custom-file-label" for="customFile">Pilih Foto</label>
                      </div>
            </div>
            <div class="col-12 col-sm-12 col-md-8 col-lg-8">
                <div class="form-group">
                    <label for="exampleInputEmail1">Nama</label>
                    <input type="text" name="name" class="form-control" id="" aria-describedby="" value="<?php echo e($produk->name); ?>"
                        placeholder="Nama produk">
                </div>
                <div class="form-group">
                    <label for="exampleFormControlSelect1">Kategori</label>
                    <select class="form-control" name="category_id" id="">
                        <option value="<?php echo e($produk->category_id); ?>" selected><?php echo e($produk->category['name']); ?></option>
                        <?php $__currentLoopData = $kategori; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kategori): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($kategori->id); ?>"><?php echo e($kategori->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="form-group">
                    <label for="exampleInputEmail1">Harga</label>
                    <input type="text" name="price" class="form-control" id="rupiah2" aria-describedby=""
                        value="Rp. <?php echo e(number_format($produk->price,0,'.','.')); ?>" placeholder="Rp.">
                </div>

                <div class="form-group">
                    <label for="exampleInputEmail1">Stok</label>
                    <input type="number" name="quantity" class="form-control" id="" aria-describedby=""
                        value="<?php echo e($produk->quantity); ?>" placeholder="Jumlah Produk">
                </div>

                <div class="form-group">
                    <label for="exampleInputEmail1">Deskripsi</label>
                    <textarea type="" name="desc" class="form-control" rows="5"
                        aria-describedby=""><?php echo e($produk->desc); ?></textarea>
                </div>
            </div>
        </div>


        <button type="submit" class="btn btn-primary w-100 mt-3">Simpan</button>
        </form>

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\krowak\resources\views/admin/editProduk.blade.php ENDPATH**/ ?>