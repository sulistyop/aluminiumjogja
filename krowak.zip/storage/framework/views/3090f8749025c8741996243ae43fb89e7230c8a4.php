
<?php $__env->startSection('title','Riwayat Belanja'); ?>

<?php $__env->startSection('content'); ?>

<div class="container mt-4">
    <nav aria-label="breadcrumb white">
        <ol class="breadcrumb pl-0">
            <li class="breadcrumb-item"><a href="<?php echo e(route('home.index')); ?>">Home</a></li>
            <li class="breadcrumb-item active" aria-current="page">Riwayat Belanja</li>
        </ol>
    </nav>

    <table class="table">
        <thead>
            <tr>
                <th scope="col">No</th>
                <th scope="col">Tanggal</th>
                <th scope="col">Jam</th>
                <th scope="col">Status</th>
                <th scope="col">Total</th>
                <th scope="col">Detail</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $order; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $no => $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <th scope="row"><?php echo e($order->firstItem()+$no); ?></th>
                <td><?php echo e($data->order_date->format('d/m/Y')); ?></td>
                <td><?php echo e($data->order_date->format('h:i:s')); ?></td>
                <td>
                    <?php if($data->status == 'checkout'): ?>
                    Belum Dibayar
                    <?php else: ?>
                    Sudah Dibayar
                    <?php endif; ?>
                </td>
                <td>Rp. <?php echo e(number_format($data->total_price,0,",",".")); ?></td>
                <td>
                    <a class="text-blue" href="<?php echo e(route('historydetail.index',['slug'=>$data->slug])); ?>">
                        <i class="fa fa-search"></i>
                    </a>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    <?php echo e($order->links()); ?>

</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\sulis\Downloads\Compressed\krowak\krowak\resources\views/checkout/history.blade.php ENDPATH**/ ?>